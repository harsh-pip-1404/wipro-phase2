﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace RecipeManagementAPI.Migrations
{
    /// <inheritdoc />
    public partial class iniitsetup : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "003e173a-358e-4aba-8d2b-6cabb2c59a18");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "adf8b32a-0e9c-47f3-a9c1-001e07908cc0");

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "1e41f6be-1e9d-4340-a882-1bf40cb61d09", "1", "Admin", "ADMIN" },
                    { "80dc3fb9-e1f0-4703-aa0d-cafb600d08a3", "2", "User", "USER" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "1e41f6be-1e9d-4340-a882-1bf40cb61d09");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "80dc3fb9-e1f0-4703-aa0d-cafb600d08a3");

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "003e173a-358e-4aba-8d2b-6cabb2c59a18", "1", "Admin", "ADMIN" },
                    { "adf8b32a-0e9c-47f3-a9c1-001e07908cc0", "2", "User", "USER" }
                });
        }
    }
}
