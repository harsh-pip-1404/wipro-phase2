﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace RecipeManagementAPI.Migrations
{
    /// <inheritdoc />
    public partial class initsetup : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "07b8c8b8-c781-4584-9125-60aa12e81696");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "af5f7519-a7ee-4242-91e4-1f92fb40aff0");

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "54012ee1-0e04-42da-9e86-5d5d5e664dd7", "2", "User", "USER" },
                    { "ed0c0fbb-f10d-4a38-914e-1d4e23b90969", "1", "Admin", "ADMIN" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "54012ee1-0e04-42da-9e86-5d5d5e664dd7");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "ed0c0fbb-f10d-4a38-914e-1d4e23b90969");

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "07b8c8b8-c781-4584-9125-60aa12e81696", "2", "User", "USER" },
                    { "af5f7519-a7ee-4242-91e4-1f92fb40aff0", "1", "Admin", "ADMIN" }
                });
        }
    }
}
