﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace RecipeManagementAPI.Migrations
{
    /// <inheritdoc />
    public partial class iniitsetupp : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3c4fd0f5-bade-4bb5-9cdc-01b98965b35f");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "f5f04c4e-6746-4961-8691-6f0a2ba948c7");

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "23f1ccc1-d325-4001-9bdd-cc21eaf2f9ce", "1", "Admin", "ADMIN" },
                    { "8d55aaff-4612-48d6-a894-f5f684c51f03", "2", "User", "USER" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "23f1ccc1-d325-4001-9bdd-cc21eaf2f9ce");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "8d55aaff-4612-48d6-a894-f5f684c51f03");

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "3c4fd0f5-bade-4bb5-9cdc-01b98965b35f", "1", "Admin", "ADMIN" },
                    { "f5f04c4e-6746-4961-8691-6f0a2ba948c7", "2", "User", "USER" }
                });
        }
    }
}
