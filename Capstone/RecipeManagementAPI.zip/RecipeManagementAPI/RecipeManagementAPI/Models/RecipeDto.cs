﻿using System.ComponentModel.DataAnnotations;

public class RecipeDto
{
    [Required]
    public string Name { get; set; }

    public string? Description { get; set; }

    [Required]
    public string Ingredients { get; set; }

    [Required]
    public string Instructions { get; set; }

    public IFormFile? ImageFile { get; set; }

    [Required]
    public string Category { get; set; }
}