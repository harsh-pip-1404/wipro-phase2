﻿using System.ComponentModel.DataAnnotations;

public class Recipe
{
    public int Id { get; set; }

    [Required]
    public string Name { get; set; }

    public string? Description { get; set; }

    [Required]
    public string Ingredients { get; set; }

    [Required]
    public string Instructions { get; set; }

    [Required]
    public string Category { get; set; }

    public string ImageUrl { get; set; }

    public string UserId { get; set; } // To track the owner
}