﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using RecipeManagementAPI.Data;
using RecipeManagementAPI.Models;
using System;
using System.IO;
using System.Security.Claims;

namespace RecipeManagementAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RecipesController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _environment;

        public RecipesController(AppDbContext context, IWebHostEnvironment environment)
        {
            _context = context;
            _environment = environment;
        }

        // ✅ 1. Get all recipes (Allow anonymous access)
        [HttpGet]
        [AllowAnonymous]
        public async Task<ActionResult<IEnumerable<Recipe>>> GetRecipes()
        {
            return await _context.Recipes.ToListAsync();
        }

        // ✅ 2. Get a recipe by ID (Allow anonymous access)
        [HttpGet("{id}")]
        [AllowAnonymous]
        public async Task<ActionResult<Recipe>> GetRecipe(int id)
        {
            var recipe = await _context.Recipes.FindAsync(id);
            if (recipe == null)
                return NotFound();
            return recipe;
        }

        // ✅ 3. Create a new recipe (Require authentication)
        [HttpPost]
        //[AllowAnonymous]
        [Authorize(Roles = "Admin")]
        [Consumes("multipart/form-data")]
        public async Task<ActionResult<Recipe>> CreateRecipe([FromForm] RecipeDto recipeDto)
        {
            var recipe = new Recipe
            {
                Name = recipeDto.Name,
                Description = recipeDto.Description,
                Category = recipeDto.Category,
                Ingredients = recipeDto.Ingredients,
                Instructions = recipeDto.Instructions,
                UserId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "anonymous" // Get current user ID
            };

            // Handle image upload if present
            if (recipeDto.ImageFile != null && recipeDto.ImageFile.Length > 0)
            {
                string uploadsFolder = Path.Combine(_environment.WebRootPath, "images");
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                string uniqueFileName = Guid.NewGuid().ToString() + "_" + recipeDto.ImageFile.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await recipeDto.ImageFile.CopyToAsync(fileStream);
                }

                recipe.ImageUrl = "/images/" + uniqueFileName;
            }

            _context.Recipes.Add(recipe);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetRecipe), new { id = recipe.Id }, recipe);
        }

        // ✅ 4. Update a recipe (Require authentication)
        [HttpPut("{id}")]
        //[AllowAnonymous]
        [Authorize(Roles = "Admin")]
        [Consumes("multipart/form-data")]
        public async Task<IActionResult> UpdateRecipe(int id, [FromForm] RecipeDto recipeDto)
        {
            var recipe = await _context.Recipes.FindAsync(id);
            if (recipe == null)
                return NotFound();

            recipe.Name = recipeDto.Name;
            recipe.Description = recipeDto.Description;
            recipe.Category = recipeDto.Category;
            recipe.Ingredients = recipeDto.Ingredients;
            recipe.Instructions = recipeDto.Instructions;

            // Handle image upload if present
            if (recipeDto.ImageFile != null && recipeDto.ImageFile.Length > 0)
            {
                // Delete old image if exists and it's not a default image
                if (!string.IsNullOrEmpty(recipe.ImageUrl) && !recipe.ImageUrl.Contains("default"))
                {
                    string oldImagePath = Path.Combine(_environment.WebRootPath, recipe.ImageUrl.TrimStart('/'));
                    if (System.IO.File.Exists(oldImagePath))
                    {
                        System.IO.File.Delete(oldImagePath);
                    }
                }

                string uploadsFolder = Path.Combine(_environment.WebRootPath, "images");
                if (!Directory.Exists(uploadsFolder))
                {
                    Directory.CreateDirectory(uploadsFolder);
                }

                string uniqueFileName = Guid.NewGuid().ToString() + "_" + recipeDto.ImageFile.FileName;
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);

                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await recipeDto.ImageFile.CopyToAsync(fileStream);
                }

                recipe.ImageUrl = "/images/" + uniqueFileName;
            }

            await _context.SaveChangesAsync();
            return NoContent();
        }

        // ✅ 5. Delete a recipe (Require authentication)
        [HttpDelete("{id}")]
        //[AllowAnonymous]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteRecipe(int id)
        {
            var recipe = await _context.Recipes.FindAsync(id);
            if (recipe == null)
                return NotFound();

            // Delete associated image file if it exists
            if (!string.IsNullOrEmpty(recipe.ImageUrl) && !recipe.ImageUrl.Contains("default"))
            {
                string imagePath = Path.Combine(_environment.WebRootPath, recipe.ImageUrl.TrimStart('/'));
                if (System.IO.File.Exists(imagePath))
                {
                    System.IO.File.Delete(imagePath);
                }
            }

            _context.Recipes.Remove(recipe);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}