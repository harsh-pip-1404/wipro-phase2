import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import RecipeList from './components/RecipeList';
import RecipeForm from './components/RecipeForm';
import Login from './components/Login';
import Register from './components/Register';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
    return (
        <Router>
            <Navbar />
            <Routes>
                <Route 
                    path="/" 
                    element={
                        <ProtectedRoute>
                            <RecipeList />
                        </ProtectedRoute>
                    } 
                />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route 
                    path="/add-recipe" 
                    element={
                        <ProtectedRoute adminOnly={true}>
                            <RecipeForm />
                        </ProtectedRoute>
                    } 
                />
                <Route 
                    path="/edit-recipe/:id" 
                    element={
                        <ProtectedRoute adminOnly={true}>
                            <RecipeForm />
                        </ProtectedRoute>
                    } 
                />
            </Routes>
        </Router>
    );
}

export default App;
