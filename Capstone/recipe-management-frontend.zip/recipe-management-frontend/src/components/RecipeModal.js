import React from 'react';

const RecipeModal = ({ recipe, onClose }) => {
    React.useEffect(() => {
        document.body.style.overflow = 'hidden';
        return () => {
            document.body.style.overflow = 'unset';
        };
    }, []);

    return (
        <div 
            style={{ 
                position: 'fixed',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundColor: 'rgba(0,0,0,0.3)',
                zIndex: 1050,
                display: 'flex',
                alignItems: 'flex-start',
                justifyContent: 'center',
                paddingTop: '2rem'
            }}
            onClick={onClose}
        >
            <div 
                className="modal-dialog modal-lg" 
                style={{ margin: 0, width: '100%', maxWidth: '800px' }}
                onClick={e => e.stopPropagation()}
            >
                <div className="modal-content bg-white shadow" style={{ maxHeight: '85vh' }}>
                    <div className="modal-header border-bottom">
                        <h5 className="modal-title fw-bold">{recipe.name}</h5>
                        <button type="button" className="btn-close" onClick={onClose}></button>
                    </div>
                    <div className="modal-body bg-light" style={{ overflowY: 'auto' }}>
                        <div className="text-center mb-4">
                            <img 
                                src={recipe.imageUrl ? `https://localhost:7152/${recipe.imageUrl}` : 'https://via.placeholder.com/300x200?text=No+Image'}
                                className="img-fluid rounded shadow"
                                alt={recipe.name}
                                style={{ maxHeight: '300px', objectFit: 'cover' }}
                            />
                        </div>
                        <div className="row bg-white p-3 rounded shadow-sm">
                            <div className="col-md-6">
                                <h6 className="fw-bold text-primary mb-3">Ingredients:</h6>
                                <ul className="list-unstyled">
                                    {recipe.ingredients && Array.isArray(recipe.ingredients) ? 
                                        recipe.ingredients.map((ingredient, index) => (
                                            <li key={index} className="mb-2">• {ingredient}</li>
                                        ))
                                        :
                                        <li>• {recipe.ingredients}</li>
                                    }
                                </ul>
                            </div>
                            <div className="col-md-6">
                                <h6 className="fw-bold text-primary mb-3">Instructions:</h6>
                                <ol className="ps-3">
                                    {recipe.instructions && Array.isArray(recipe.instructions) ? 
                                        recipe.instructions.map((instruction, index) => (
                                            <li key={index} className="mb-2">{instruction}</li>
                                        ))
                                        :
                                        <li>{recipe.instructions}</li>
                                    }
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default RecipeModal;