import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { authService } from '../services/AuthService';

const Login = () => {
    const [credentials, setCredentials] = useState({
        userName: '',
        password: ''
    });
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleChange = (e) => {
        setCredentials({
            ...credentials,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await authService.login(credentials);
            window.dispatchEvent(new Event('login'));
            navigate('/');
        } catch (error) {
            setError('Invalid username or password');
        }
    };

    return (
        <div className="d-flex justify-content-center align-items-center vh-100 bg-light">
            <div className="col-md-4 col-sm-6 col-11">
                <div className="card shadow-lg border-0 rounded-4">
                    <div className="card-header bg-primary text-white text-center py-3 rounded-top">
                        <h3 className="mb-0">Login</h3>
                    </div>
                    <div className="card-body p-4">
                        {error && (
                            <div className="alert alert-danger alert-dismissible fade show" role="alert">
                                {error}
                                <button type="button" className="btn-close" onClick={() => setError('')}></button>
                            </div>
                        )}
                        <form onSubmit={handleSubmit} className="d-flex flex-column align-items-center">
                            <div className="mb-3 w-100">
                                <label className="form-label">Username</label>
                                <input
                                    type="text"
                                    className="form-control"
                                    name="userName"
                                    value={credentials.userName}
                                    onChange={handleChange}
                                    required
                                    placeholder="Enter username"
                                />
                            </div>
                            <div className="mb-4 w-100">
                                <label className="form-label">Password</label>
                                <input
                                    type="password"
                                    className="form-control"
                                    name="password"
                                    value={credentials.password}
                                    onChange={handleChange}
                                    required
                                    placeholder="Enter password"
                                />
                            </div>
                            <button type="submit" className="btn btn-primary w-100 py-2 mb-3">
                                Login
                            </button>
                        </form>
                        <div className="text-center">
                            <Link to="/register" className="text-decoration-none">
                                New user? Register here
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Login;
