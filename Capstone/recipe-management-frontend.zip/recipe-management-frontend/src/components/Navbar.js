import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { authService } from '../services/AuthService';

const Navbar = () => {
    const [user, setUser] = useState(authService.getCurrentUser());
    const [isAdmin, setIsAdmin] = useState(authService.isAdmin());
    const navigate = useNavigate();

    useEffect(() => {
        // Update user state when localStorage changes
        const handleStorageChange = () => {
            setUser(authService.getCurrentUser());
            setIsAdmin(authService.isAdmin());
        };

        window.addEventListener('storage', handleStorageChange);
        // Custom event for login
        window.addEventListener('login', handleStorageChange);

        return () => {
            window.removeEventListener('storage', handleStorageChange);
            window.removeEventListener('login', handleStorageChange);
        };
    }, []);

    const handleLogout = () => {
        authService.logout();
        setUser(null);
        setIsAdmin(false);
        navigate('/login');
    };

    return (
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
            <div className="container">
                <Link className="navbar-brand" to="/">Recipe Management</Link>
                <div className="navbar-collapse">
                    <ul className="navbar-nav me-auto">
                        {user && (
                            <>
                                <li className="nav-item">
                                    <span className="nav-link">Welcome, {user.username}!</span>
                                </li>
                                {isAdmin && (
                                    <li className="nav-item">
                                        <Link className="nav-link" to="/add-recipe">Add Recipe</Link>
                                    </li>
                                )}
                            </>
                        )}
                    </ul>
                    <ul className="navbar-nav">
                        {!user ? (
                            <>
                                <li className="nav-item">
                                    <Link className="nav-link" to="/login">Login</Link>
                                </li>
                                <li className="nav-item">
                                    <Link className="nav-link" to="/register">Register</Link>
                                </li>
                            </>
                        ) : (
                            <li className="nav-item">
                                <button 
                                    className="nav-link btn btn-link" 
                                    onClick={handleLogout}
                                >
                                    Logout
                                </button>
                            </li>
                        )}
                    </ul>
                </div>
            </div>
        </nav>
    );
};

export default Navbar;