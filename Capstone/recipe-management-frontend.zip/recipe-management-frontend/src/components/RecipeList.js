import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { recipeService } from '../services/RecipeService';
import { authService } from '../services/AuthService';
import RecipeModal from './RecipeModal';

const RecipeList = () => {
    const [recipes, setRecipes] = useState([]);
    const [error, setError] = useState('');
    const [selectedRecipe, setSelectedRecipe] = useState(null);
    const isAdmin = authService.isAdmin();
    
    
    console.log('Current user:', authService.getCurrentUser());
    console.log('Is Admin:', isAdmin);

    useEffect(() => {
        loadRecipes();
    }, []);

    const loadRecipes = async () => {
        try {
            const data = await recipeService.getAllRecipes();
            setRecipes(data);
        } catch (error) {
            setError('Failed to load recipes');
            console.error('Error loading recipes:', error);
        }
    };

    const handleDelete = async (id) => {
        if (window.confirm('Are you sure you want to delete this recipe?')) {
            try {
                await recipeService.deleteRecipe(id);
                loadRecipes();
            } catch (error) {
                setError(error.message || 'Failed to delete recipe');
            }
        }
    };

    return (
        <div className="container" style={{ 
            paddingTop: '1rem',
            paddingBottom: '1rem',
            minHeight: '100vh'
        }}>
            <h2 className="text-center mb-4">Our Recipes</h2>
            {error && <div className="alert alert-danger">{error}</div>}
            <div className="row g-4">
                {recipes.map(recipe => (
                    <div key={recipe.id} className="col-md-4 mb-4">
                        <div className="card shadow-sm hover-shadow">
                            {recipe.imageUrl && (
                                <img 
                                    src={`https://localhost:7152/${recipe.imageUrl}`}
                                    className="card-img-top" 
                                    alt={recipe.name}
                                    style={{ height: '200px', objectFit: 'cover' }}
                                    onError={(e) => {
                                        e.target.onerror = null;
                                        e.target.src = 'https://via.placeholder.com/300x200?text=No+Image';
                                    }}
                                />
                            )}
                            <div className="card-body">
                                <h5 className="card-title">{recipe.name}</h5>
                                <p className="card-text">{recipe.description}</p>
                                <p className="card-text">
                                    <small className="text-muted">Category: {recipe.category}</small>
                                </p>
                                <button 
                                    className="btn btn-outline-primary w-100"
                                    onClick={() => setSelectedRecipe(recipe)}
                                >
                                    Click to Know This Recipe
                                </button>
                                {isAdmin && (
                                    <div className="mt-3">
                                        <Link 
                                            to={`/edit-recipe/${recipe.id}`} 
                                            className="btn btn-primary me-2"
                                        >
                                            Edit
                                        </Link>
                                        <button 
                                            onClick={() => handleDelete(recipe.id)}
                                            className="btn btn-danger"
                                        >
                                            Delete
                                        </button>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                ))}
            </div>
            {selectedRecipe && <RecipeModal recipe={selectedRecipe} onClose={() => setSelectedRecipe(null)} />}
        </div>
    );
};

export default RecipeList;
