import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { recipeService } from '../services/RecipeService';
import { authService } from '../services/AuthService';

const RecipeForm = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [error, setError] = useState('');
    const [recipe, setRecipe] = useState({
        name: '',
        description: '',
        ingredients: '',
        instructions: '',
        category: '',
        image: null
    });

    const loadRecipe = useCallback(async () => {
        try {
            const data = await recipeService.getAllRecipes();
            const existingRecipe = data.find(r => r.id === parseInt(id));
            if (existingRecipe) {
                setRecipe({
                    ...existingRecipe,
                    image: null
                });
            }
        } catch (error) {
            setError('Failed to load recipe');
        }
    }, [id]);

    useEffect(() => {
        if (!authService.isAdmin()) {
            navigate('/');
            return;
        }

        if (id) {
            loadRecipe();
        }
    }, [id, navigate, loadRecipe]);

    const handleChange = (e) => {
        const { name, value, files } = e.target;
        if (name === 'image') {
            setRecipe({ ...recipe, image: files[0] });
        } else {
            setRecipe({ ...recipe, [name]: value });
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            if (id) {
                await recipeService.updateRecipe(id, recipe);
            } else {
                await recipeService.createRecipe(recipe);
            }
            navigate('/');
        } catch (error) {
            setError(error.message || 'Failed to save recipe');
        }
    };

    return (
        <div className="container mt-4">
            <h2>{id ? 'Edit Recipe' : 'Add New Recipe'}</h2>
            {error && <div className="alert alert-danger">{error}</div>}
            <form onSubmit={handleSubmit}>
                <div className="mb-3">
                    <label className="form-label">Name</label>
                    <input
                        type="text"
                        className="form-control"
                        name="name"
                        value={recipe.name}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="mb-3">
                    <label className="form-label">Description</label>
                    <textarea
                        className="form-control"
                        name="description"
                        value={recipe.description}
                        onChange={handleChange}
                    />
                </div>
                <div className="mb-3">
                    <label className="form-label">Ingredients</label>
                    <textarea
                        className="form-control"
                        name="ingredients"
                        value={recipe.ingredients}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="mb-3">
                    <label className="form-label">Instructions</label>
                    <textarea
                        className="form-control"
                        name="instructions"
                        value={recipe.instructions}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="mb-3">
                    <label className="form-label">Category</label>
                    <input
                        type="text"
                        className="form-control"
                        name="category"
                        value={recipe.category}
                        onChange={handleChange}
                        required
                    />
                </div>
                <div className="mb-3">
                    <label className="form-label">Image</label>
                    <input
                        type="file"
                        className="form-control"
                        name="image"
                        onChange={handleChange}
                        accept="image/*"
                    />
                </div>
                <button type="submit" className="btn btn-primary">
                    {id ? 'Update Recipe' : 'Add Recipe'}
                </button>
            </form>
        </div>
    );
};

export default RecipeForm;
