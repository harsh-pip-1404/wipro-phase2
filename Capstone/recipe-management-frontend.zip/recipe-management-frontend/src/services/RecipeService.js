import axios from 'axios';
import { authService } from './AuthService';

const API_URL = 'https://localhost:7152/api/Recipes';

// Add axios interceptor to add auth token to all requests
axios.interceptors.request.use(
    (config) => {
        const user = authService.getCurrentUser();
        if (user?.token) {
            config.headers.Authorization = `Bearer ${user.token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

export const recipeService = {
    getAllRecipes: async () => {
        const response = await axios.get(API_URL);
        return response.data;
    },

    createRecipe: async (recipe) => {
        try {
            if (!authService.isAdmin()) {
                throw new Error('Unauthorized: Admin access required');
            }

            // Set default category if not provided
            const recipeWithDefaults = {
                ...recipe,
                category: recipe.category || 'General' // Provide a default category
            };

            // Detailed validation for required fields
            const requiredFields = {
                name: recipeWithDefaults.name,
                ingredients: recipeWithDefaults.ingredients,
                instructions: recipeWithDefaults.instructions,
                category: recipeWithDefaults.category
            };

            const missingFields = Object.entries(requiredFields)
                .filter(([_, value]) => !value || value.trim() === '')
                .map(([field]) => field);

            if (missingFields.length > 0) {
                throw new Error(`Missing required fields: ${missingFields.join(', ')}`);
            }

            const formData = new FormData();
            
            // Required fields from RecipeDto
            formData.append('name', recipeWithDefaults.name);
            formData.append('ingredients', recipeWithDefaults.ingredients);
            formData.append('instructions', recipeWithDefaults.instructions);
            formData.append('category', recipeWithDefaults.category);
            
            // Optional field
            if (recipe.description) {
                formData.append('description', recipe.description);
            }
            
            // Handle image file
            if (recipe.image instanceof File) {
                formData.append('imageFile', recipe.image);
            }

            // Debug logging
            console.log('Sending recipe data:');
            for (let pair of formData.entries()) {
                console.log(`${pair[0]}: ${pair[1]}`);
            }

            const response = await axios.post(API_URL, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            return response.data;
        } catch (error) {
            if (error.message.includes('required fields')) {
                console.error('Validation Error:', error.message);
            } else {
                console.error('Create Recipe Error:', error.response?.data);
                console.error('Full error details:', error);
            }
            if (error.response?.status === 401) {
                authService.logout(); // Clear invalid tokens
                throw new Error('Session expired. Please login again.');
            }
            throw error;
        }
    },

    updateRecipe: async (id, recipe) => {
        try {
            if (!authService.isAdmin()) {
                throw new Error('Unauthorized: Admin access required');
            }

            // Detailed validation for required fields
            const requiredFields = {
                name: recipe.name,
                ingredients: recipe.ingredients,
                instructions: recipe.instructions,
                category: recipe.category
            };

            const missingFields = Object.entries(requiredFields)
                .filter(([_, value]) => !value)
                .map(([field]) => field);

            if (missingFields.length > 0) {
                throw new Error(`Missing required fields: ${missingFields.join(', ')}`);
            }

            const formData = new FormData();
            
            // Required fields from RecipeDto
            formData.append('name', recipe.name);
            formData.append('ingredients', recipe.ingredients);
            formData.append('instructions', recipe.instructions);
            formData.append('category', recipe.category);
            
            // Optional field
            if (recipe.description) {
                formData.append('description', recipe.description);
            }
            
            // Handle image file
            if (recipe.image instanceof File) {
                formData.append('imageFile', recipe.image);
            }

            await axios.put(`${API_URL}/${id}`, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
        } catch (error) {
            if (error.message.includes('required fields')) {
                console.error('Validation Error:', error.message);
            } else {
                console.error('Update Recipe Error:', error.response?.data);
            }
            if (error.response?.status === 401) {
                authService.logout();
                throw new Error('Session expired. Please login again.');
            }
            throw error;
        }
    },

    deleteRecipe: async (id) => {
        try {
            if (!authService.isAdmin()) {
                throw new Error('Unauthorized: Admin access required');
            }

            await axios.delete(`${API_URL}/${id}`);
        } catch (error) {
            console.error('Delete Recipe Error:', error.response?.data);
            if (error.response?.status === 401) {
                authService.logout();
                throw new Error('Session expired. Please login again.');
            }
            throw error;
        }
    }
};
