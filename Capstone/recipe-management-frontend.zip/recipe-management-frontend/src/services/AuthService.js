import axios from 'axios';

const API_URL = 'https://localhost:7152/api/Auth';

export const authService = {
    login: async (credentials) => {
        try {
            const response = await axios.post(`${API_URL}/login`, credentials);
            const user = response.data;
            localStorage.setItem('user', JSON.stringify(user));
            return user;
        } catch (error) {
            throw error;
        }
    },

    getCurrentUser: () => {
        const user = localStorage.getItem('user');
        if (!user) return null;
        
        const userData = JSON.parse(user);
        if (!userData.token) return null;

        // Decode JWT token
        const tokenPayload = JSON.parse(atob(userData.token.split('.')[1]));
        return {
            ...userData,
            username: tokenPayload['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name'],
            role: tokenPayload['http://schemas.microsoft.com/ws/2008/06/identity/claims/role']
        };
    },

    isAdmin: () => {
        const user = localStorage.getItem('user');
        if (!user) return false;
        
        const userData = JSON.parse(user);
        if (!userData.token) return false;

        // Decode JWT token
        const tokenPayload = JSON.parse(atob(userData.token.split('.')[1]));
        // Check for Admin role in claims
        return tokenPayload['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'] === 'Admin';
    },

    logout: () => {
        localStorage.removeItem('user');
    }
};