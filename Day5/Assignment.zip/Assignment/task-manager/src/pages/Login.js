import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

// ✅ Define valid username-password pairs
const allowedUsers = {
  harsh: "1234",
  admin: "admin123",
  john: "pass456",
};

const Login = () => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = () => {
    if (allowedUsers[username] && allowedUsers[username] === password) {
      // ✅ Store login status & user info
      localStorage.setItem("isAuthenticated", "true");
      localStorage.setItem("username", username);
      navigate("/dashboard"); // ✅ Redirect to Dashboard
    } else {
      alert("Invalid username or password! Please try again.");
    }
  };

  return (
    <div>
      <h2>Login</h2>
      <input
        type="text"
        placeholder="Enter Username"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
      />
      <input
        type="password"
        placeholder="Enter Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <button onClick={handleLogin}>Login</button>
    </div>
  );
};

export default Login;
