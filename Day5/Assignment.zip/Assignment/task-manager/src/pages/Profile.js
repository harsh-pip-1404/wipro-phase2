import React from "react";

const Profile = () => {
  const username = localStorage.getItem("username"); // ✅ Fetch stored username

  return (
    <div>
      <h2>Profile</h2>
      {username ? <p>Username: {username}</p> : <p>No user logged in.</p>}
    </div>
  );
};

export default Profile;
