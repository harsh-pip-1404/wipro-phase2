import { combineReducers } from "redux";

const authReducer = (state = JSON.parse(localStorage.getItem("auth")) || null, action) => {
  switch (action.type) {
    case "LOGIN_SUCCESS":
      return action.payload;
    case "LOGOUT":
      return null;
    default:
      return state;
  }
};

const taskReducer = (state = [], action) => {
  switch (action.type) {
    case "ADD_TASK":
      return [...state, action.payload];
    case "DELETE_TASK":
      return state.filter(task => task.id !== action.payload);
    default:
      return state;
  }
};

export default combineReducers({ auth: authReducer, tasks: taskReducer });
