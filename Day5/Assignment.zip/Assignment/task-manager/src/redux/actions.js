export const loginUser = (user) => (dispatch) => {
    localStorage.setItem("auth", JSON.stringify(user));
    dispatch({ type: "LOGIN_SUCCESS", payload: user });
  };
  
  export const logoutUser = () => (dispatch) => {
    localStorage.removeItem("auth");
    dispatch({ type: "LOGOUT" });
  };
  
  export const addTask = (task) => ({
    type: "ADD_TASK",
    payload: task,
  });
  
  export const deleteTask = (taskId) => ({
    type: "DELETE_TASK",
    payload: taskId,
  });
  