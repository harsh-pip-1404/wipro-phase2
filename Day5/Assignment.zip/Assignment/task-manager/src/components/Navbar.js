import React from "react";
import { Link, useNavigate } from "react-router-dom";

const Navbar = () => {
  const navigate = useNavigate();

  const handleLogout = () => {
    localStorage.removeItem("isAuthenticated");
    localStorage.removeItem("username");
    navigate("/login"); // Redirect to login after logout
  };

  return (
    <nav>
      <Link to="/">Home</Link> | <Link to="/dashboard">Dashboard</Link> | <Link to="/profile">Profile</Link>
      <button onClick={handleLogout} style={{ marginLeft: "10px" }}>Logout</button>
    </nav>
  );
};

export default Navbar;
